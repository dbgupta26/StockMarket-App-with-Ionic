export const SITE_URL:string = "https://ionic2news-imsingh.rhcloud.com";
export const GOOGLE_ANALYTICS_ID:string ="UA-78447533-1";
export const GCM_SENDER_ID:string = "366304107774";